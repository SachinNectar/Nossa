import React from 'react'

function HrDemo() {
  return (
    <div></div>
  )
}

export default HrDemo